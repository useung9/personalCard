--------------------------------------------------------
--  ������ ������ - �����-3��-05-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence IMG_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRACTICE"."IMG_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_INFO_CAREER_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRACTICE"."USER_INFO_CAREER_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_INFO_EDU_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRACTICE"."USER_INFO_EDU_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_INFO_LICEN_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRACTICE"."USER_INFO_LICEN_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_INFO_QUALIFI_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRACTICE"."USER_INFO_QUALIFI_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_INFO_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRACTICE"."USER_INFO_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 41 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_INFO_SKILL_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRACTICE"."USER_INFO_SKILL_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence USER_INFO_TRAINING_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PRACTICE"."USER_INFO_TRAINING_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 61 CACHE 20 NOORDER  NOCYCLE ;

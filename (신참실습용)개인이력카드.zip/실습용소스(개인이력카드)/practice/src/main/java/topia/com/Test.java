package topia.com;

import topia.com.util.Sha256;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Sha256.encrypt("9312121234567"));
		System.out.println(Sha256.encrypt("9312121234567"));
		System.out.println(Sha256.encrypt("9312121234567"));
		System.out.println(Sha256.encrypt("9312121234567"));
		System.out.println(Sha256.encrypt("9312121234567"));
		System.out.println(Sha256.encrypt("9312121234567"));
	}

}
